cloudify-fabric-plugin
======================

For running fabric tasks or commands from the manager
