# Cloudify Fabric Plugin

[![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-fabric-plugin.svg?style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-fabric-plugin)

This plugin allows running SSH commands and Fabric Tasks remotely..

## Usage

See [Fabric Plugin](http://docs.getcloudify.org/latest/plugins/fabric/)
